class Paras {
public static void main(String ar[])
{
System.out.println("Hello People");
}
}