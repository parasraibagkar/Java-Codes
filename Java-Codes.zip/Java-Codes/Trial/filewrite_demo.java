import java.io.*;
class filewrite_demo
{
public static void main(String ar[]) throws IOException
{
String s="This is demo program";
char ch[] = s.toCharArray();
int x=s.length();
FileOutputStream fout;
int i=0;
try
{
fout = new FileOutputStream("abc.txt");
}
catch(FileNotFoundException e)
{
System.out.println("File cannot be created");
return;
}
for(i=0;i<x;i++)
{
fout.write(ch[i]);
}
fout.close();
}
}