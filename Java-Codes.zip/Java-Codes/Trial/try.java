 class Y
{
	abstract Y() 
	{
		System.out.println("Hello from Constructor of Y ");
	}	
	static {
	System.out.println("Hello from static block of Y");	
	}
}
class C extends Y{
	static { 
		System.out.println("Hello from static block of C");	
	}
}
 class B
{
	public static void main(String[] args) {
	  	Y c1 =new Y();
	  		
	  	//y1.set();
	  	 
		/*
		Y.set();
		Y.set();
		*/
	}
}