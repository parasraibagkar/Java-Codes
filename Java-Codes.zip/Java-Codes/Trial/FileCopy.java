import java.io.*;
class FileCopy
{
public static void main(String ar[]) throws IOException
{
int a;

FileInputStream fin;
FileOutputStream fout;

try
{
fin = new FileInputStream("File1.txt");
fout = new FileOutputStream("new_file.txt");

do
{
a=fin.read();

if(a!=-1)
{
	fout.write(a);
}
}while(a!=-1);
fin.close();
fout.close();
System.out.println("File Copied...");

}
catch(FileNotFoundException e)
{
System.out.println("Unable to open the file to read from.");
}

}
}