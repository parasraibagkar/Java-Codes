import java.io.*;
class fileread_demo
{
public static void main(String ar[]) throws IOException
{
int a;
FileInputStream fin;
try
{
fin = new FileInputStream("xyz.txt");
}
catch(FileNotFoundException e)
{
System.out.println("File not found");
return;
}
do
{
a=fin.read();
if(a!=-1)
{
	//System.out.print((char)a);
	
}
}while(a!=-1);
fin.close();
}
}
