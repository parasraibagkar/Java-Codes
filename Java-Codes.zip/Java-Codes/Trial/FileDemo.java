import java.io.*;

class FileDemo
{
public static void main(String ar[ ]) throws IOException
{
String fname,msg;
String s = "";
char ch;
DataInputStream dis = new DataInputStream(System.in);
System.out.println("Enter file name");
fname = dis.readLine();
System.out.println("Start writing into file");
do{
	ch = (char)dis.read();
	if(ch!='@')
	{
		s= s + ch;
	}
//msg = dis.readLine();
}while(ch!='@');
try
{
	FileOutputStream fout = new FileOutputStream(fname);
	for(int i=0;i<s.length(); i++)
	{				//msg.length()
					//msg.charAt(i)
		fout.write(s.charAt(i));
	}
	System.out.println("\ncontents are written into file");
}
catch(Exception ex)
{
System.out.println("" + ex);
}
System.out.println("\nmain ends");
}
}






/*
int x;
try
{
	FileInputStream fin = new FileInputStream(fname);
	System.out.println("contents of file are\n");
	do
	{
	x = fin.read( );	
	if(x!=-1)
	{
	System.out.print((char)x);
	}
	}while(x!=-1);
	fin.close( );
}
catch(FileNotFoundException ex)
{
System.out.println("No such file found");
}
System.out.println("\n\nmain ends");
}
}
*/
/*

			do 
			{
			i = fin.read( );
			if(i != -1) fout.write(i);
			} while(i != -1);

*/












