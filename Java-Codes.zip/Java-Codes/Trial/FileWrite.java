import java.io.*;
public class FileWrite
{
public static void main(String ar[ ])throws IOException
{
int roll;
String name,city;

DataInputStream dis = new DataInputStream(System.in);

File file = new File("Student_Data.txt");
file.createNewFile( );
FileWriter writer = new FileWriter(file); 

System.out.println("Enter Student's Roll number");
roll = Integer.parseInt(dis.readLine( ));

System.out.println("Enter Student's Name");
name = dis.readLine( );

System.out.println("Enter Student's City");
city = dis.readLine( );

//Writing student data into the file
writer.write("Roll Number is : " + roll); 
writer.write("Name is : " + name); 
writer.write("City is : " + city); 
writer.flush( );
writer.close( );
System.out.println("Student Data saved into the file..");
}
}
