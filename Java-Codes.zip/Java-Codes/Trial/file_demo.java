import java.io.File;
import java.util.*;
import java.text.*;

class file_demo
{
public static void main(String args[])
{
File f1 = new File("C:\\Users\\Raibagkar\\Desktop\\Trial","File1.txt");
SimpleDateFormat fm = new SimpleDateFormat("DD/MM/YYYY HH:MM:SS");

System.out.println("\nFile Name: " + f1.getName());
System.out.println("\nPath: " + f1.getPath());
System.out.println("\nAbsolute Path: " + f1.getAbsolutePath());
System.out.println("\nParent: " + f1.getParent());
System.out.println("\nDoes file exists? : " +(f1.exists()? "Yes" : "No"));
System.out.println("\nIs file Writable? : "+(f1.canWrite() ? "Yes" : "No"));
System.out.println("\nIs file Readable? : "+(f1.canRead() ? "Yes" : "No"));
System.out.println("\nIs it a directory? : " + (f1.isDirectory() ? "Yes" : "No"));
System.out.println(f1.isFile() ? "\nis normal file" : "\nmight be a named pipe");
System.out.println(f1.isAbsolute() ? "\nis absolute" : "\nis not absolute");
System.out.println("\nFile last modified : " + fm.format(f1.lastModified()));
System.out.println("\nFile size : " + f1.length() + " Bytes");
}
}