class Dir{
	
public static void main(String[] args) throws java.io.IOException {
	
Runtime rt = Runtime.getRuntime();
Process proc = rt.exec("mkdir Direc");
}
}