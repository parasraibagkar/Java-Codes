import java.sql.*;
import java.io.*;

class DBTest {
	public static void main(String[] args)throws IOException {
		int r;
		String n,c;

		DataInputStream dis = new DataInputStream(System.in);
		System.out.println("Enter Roll No. ");
		r = Integer.parseInt(dis.readLine());
		System.out.println("Enter Name. ");
		n = dis.readLine();
		System.out.println("Enter City ");
		c = dis.readLine();

		try{
			//Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			
			 Connection con=DriverManager.getConnection("jdbc:ucanaccess://G:\\Database1.accdb");

			 //Connection con = DriverManager.getConnection("jdbc.odbc.temp");
			Statement st = con.createStatement();
			String q = "Insert in student (sroll,sname,scity) values ("+r+",'"+n+"','"+c+"')";
			st.executeUpdate(q);
			con.close();
			System.out.println("Data Inserted");   
		}	
			catch (Exception e) {
				System.out.println("Data Insertion Failed "+e);
			}
		
	}
} 