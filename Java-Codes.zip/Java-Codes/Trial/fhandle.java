import java.io.*;
class fhandle
{
	public static void main(String[] args)throws IOException {
		int ch;
		try
		{
			FileReader fr=new FileReader("File1.txt");
			do
			{
				ch = fr.read();
				if(ch!=-1)
				{
					System.out.print((char)ch);

				}

			}while(ch!=-1);
          fr.close();

		}
		catch(FileNotFoundException fe)
		{
			System.out.println("Invalid Name");
		}
	}
}