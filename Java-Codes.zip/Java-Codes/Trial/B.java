 interface A {
	 public int x=1;
	 void check();
}

 class B implements A{
	public final static int x=4;

	void test()
	{
		final int z=6;
	}	
}

/*
class C
{
	public static void main(String[] args) {
		System.out.println("interface A "+A.x);
		System.out.println("class B "+B.x);
	}
}
*/