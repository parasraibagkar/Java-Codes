class Sover{
	static {
		SOP.disp("Static Hello");
		System.exit(0);
	/*public void hello()
	{
		SOP.disp("Static Hello");
	}
	public void hello()
	{
		SOP.disp("hello overloaded");
	}*/
}

	/*public static void main(String[] args) {
		Sover so = new Sover();
		hello();
		so.hello(4);
	}*/
}