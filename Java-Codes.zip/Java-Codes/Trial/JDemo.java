class JDemo
{
	public static void main(String[] args) {
		String nm = "ravi",ct="jalna";
		int rm = 35;
		 System.out.println("Insert in student (sroll,sname,scity) values ("+rm+",'"+nm+"','"+ct+"');");
	}
}