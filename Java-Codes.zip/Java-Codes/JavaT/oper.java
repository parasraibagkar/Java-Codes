package p2;

public interface oper {
	public void jack();
}