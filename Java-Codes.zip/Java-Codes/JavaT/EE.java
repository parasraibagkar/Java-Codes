class A extends Thread
{
	public void run() throws ArithmeticException
	{
		int i;
		for(i=1;i<=5;i++)
		{
			System.out.println("Thread A : " + i);
		}

		int c = 6/0;
		System.out.println("End of thread A");
	}
}

class B extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("Thread B : " + i);
		}

	}
}

class C extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("Thread C : " + i);
		}
	}
}



class D extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("Thread D : " + i);
		}
	}
}


class EE {
	public static void main(String[] args)
	{
		System.out.println("main starts");
		A a1 = new A();
		B b1 = new B();
		C c1 = new C();
		D d1 = new D();

		a1.start();
		b1.start();
		c1.start();
		d1.start();
		System.out.println("main ends");
	}
}