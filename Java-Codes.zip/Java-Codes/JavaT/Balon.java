package p2;

public class Balon {
	public void set()
	{
		System.out.println("this is set method of class B in package p2");
	}
}