public class SOP {
	public static void disp(String text)
	{
		System.out.println(text);
	}
}