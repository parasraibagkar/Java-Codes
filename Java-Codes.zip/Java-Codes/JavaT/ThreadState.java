class A implements Runnable
{
	public void test()
	{
		System.out.println("Thread");
	}
	public void run() { test();
	}
}

class ThreadState
{
	public static void main(String[] args) throws InterruptedException {
		A a1 = new A();
		Thread t1 = new Thread(a1);
			t1.start();
		//a1.suspend();
		t1.stop();
		//A a2 = new A();
		//a2.stop();
		
	}
}