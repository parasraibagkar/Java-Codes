interface A {
	public void test()throws Exception;
}

class B implements A {
	public void test()throws ArithmeticException
	{
		System.out.println("Method Test");
	}
}