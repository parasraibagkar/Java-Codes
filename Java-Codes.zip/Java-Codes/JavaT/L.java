class L {

public void test (A ref)
{
	ref.set();
}
}