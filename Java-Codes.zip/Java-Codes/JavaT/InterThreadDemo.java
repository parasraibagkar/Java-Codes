
class Communication
{
	boolean flag = false;
	public synchronized void State(String msg) throws InterruptedException
	{
		if (flag)
		{
			wait();
		}
		System.out.println("State : " + msg);
		flag = true;
		notify( );
	}
	public synchronized void Capital(String msg) throws InterruptedException
	{
		if (!flag)
		{
			wait();	
		}
		System.out.println("Capital : " + msg + "\n");
		flag = false;
		notify( );
	}
}


class T1 implements Runnable
{
	Communication m;
	String s1[ ] = {"Maharashtra","kerala","Karnataka","Gujarat"};
	public T1(Communication m1)
	{
		this.m = m1;
		new Thread(this, "State").start( );
	}
	public void run( )
	{
		for (int i = 0; i < s1.length; i++)
		{
			try{
				m.State(s1[i]);
			}
			catch(InterruptedException ie)
			{System.out.println(ie);}
		}
	}
}
class T2 implements Runnable
{
	Communication m;
	String s2[ ] = {"Mumbai","Thiruvananthapuram","Bangaluru","Gandhinagar"};
	public T2(Communication m2)
	{
		this.m = m2;
		new Thread(this, "Capital").start( );
	}
	public void run( )
	{
		for (int i = 0; i < s2.length; i++)
		{
			 try{
				m.Capital(s2[i]);
			 }
			catch(InterruptedException ie)
			{System.out.println(ie);}
		}
	}
}

public class InterThreadDemo
{
	public static void main(String args[ ])
	{
		System.out.println( );
		Communication m = new Communication( );
		new T1(m);
		new T2(m);
	}
}
