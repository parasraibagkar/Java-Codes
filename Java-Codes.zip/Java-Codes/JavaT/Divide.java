import java.io.*;

class Divide extends Exception{
  public void arith()throws IOException{
    int a,b,c;
    System.out.println("Enter Two Numbers");
    DataInputStream dis = new DataInputStream(System.in);
    try {
    a=Integer.parseInt(dis.readLine());
    b=Integer.parseInt(dis.readLine());
    c=a/b;
    System.out.println("Result is C:"+c);
    }
  catch (ArithmeticException e) {
    System.out.println("Exception Please Re-enter values ");
    a=Integer.parseInt(dis.readLine());
    b=Integer.parseInt(dis.readLine());
    c=a/b;
    System.out.println("Result is C:"+c);

  }
  

}
}
