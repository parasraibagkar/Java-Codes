//program to study threads
class A extends Thread
{
	public void test(){
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println(" 	Thread A: "+i);
		}//for ends
	}//run ends
	public void run() {
		test();
	}
}//class ends

class B extends Thread
{
	public void test(){
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Thread B: "+i);
		}//if ends
	}//run ends
	public void run() {
		test();
	}
}//class ends

class C extends Thread
{
	public void test(){
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Normal Method C: "+i);
		}//if ends
	}//run ends
	public void run() {
		synchronized(this){
		test();
		}
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Thread C: "+i);
		}
	}
}//class ends
class MyThread {
	public static void main(String[] args) {
		System.out.println("Main starts");
		A a1 = new A();
		B b1 = new B();
		C c1 = new C();
		a1.start();	
		b1.start();
		c1.start();
		System.out.println("Main ends");
	}
}