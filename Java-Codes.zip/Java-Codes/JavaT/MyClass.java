//Program for super keyword

class A {
	public A(int p)
	{}
}

class B extends A {
	public B(int x)
	{		
		super(x);
		System.out.println("");
	}
}
class C {
	public static void main(String[] args) {
		B b1 = new B(10);
	}
}