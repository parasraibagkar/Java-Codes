class DemoString
{
	public static void main(String[] args) {
		StringBuffer s= "paras";
		s.reverse().charAt(1);
	}
}