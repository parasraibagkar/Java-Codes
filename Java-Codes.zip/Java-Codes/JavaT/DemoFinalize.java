class Test
{
	public Test()
	{
		System.out.println("This is Constructor ");
	}
	public void finalize()
	{
		System.out.println("This is Finalize ");	
	}
}

class B {
	public void put()
	{
		System.out.println("put Starts ");
		Test t1 = new Test();
		Test t2 = new Test();
		System.out.println("put Ends");
		//Runtime.runFinalizersOnExit(true);
	}
}

class DemoFinalize {
	public static void main(String[] args) {
		int n=10;
		//Runtime r = new Runtime();
		System.out.println("Main Starts ");
		Test t1 = new Test();
		Test t2 = new Test();
		
		System.out.println("Calling put method");
		B b1 = new B();
		b1.put();
		
		System.out.println("back in Main ");
		System.gc();
		System.out.println("Main Ends");
	}//scope of t1 & t2 ends
		 
}