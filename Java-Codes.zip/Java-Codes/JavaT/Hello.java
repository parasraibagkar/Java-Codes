import p1.*;
import p2.*;

class  Hello {
	public static void main(String[] args) {
		p1.A a1 = new p1.A();
		p2.A a2 = new p2.A();
		p2.Balon b1 = new p2.Balon();
		a1.check();
		a2.put();
		b1.set();
	}
}