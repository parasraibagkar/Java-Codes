class DemoThis {
	int x = 5, y=10;

	void test(){ 
	int x = 50, y=100;
	System.out.println("Local X= "+x);
	System.out.println("Local Y= "+y);
	System.out.println("Data Mem X= "+this.x);
	System.out.println("Data Mem Y= "+this.y);
	}

	public static void main(String[] args) {
		DemoThis dt = new DemoThis();
		dt.test();
	}
}

