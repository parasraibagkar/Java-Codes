class TCF {
	public static void main(String[] args) {
		try{
			System.out.println("Outer try");
			int a[] = {10,20,30};
			int c = a[4]/10;
		try
		{	System.out.println("Inner try");
			 
		}//inner try end
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Inner Catch"+e);
		}//inner catch end
		finally{
			System.out.println("inner finally");
		}//inner finally end
		}
		catch(ArithmeticException e) {
			System.out.println("Outer Catch"+e);
		}
		finally{
			System.out.println("outer finally");
		}//outer finally end
	}
}