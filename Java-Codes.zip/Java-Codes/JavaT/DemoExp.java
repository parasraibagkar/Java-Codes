import java.io.*;
	
class D 
{
	public void test() 
	{
		int n=0;
		DataInputStream dis = new DataInputStream(System.in);
		System.out.println("Enter a number ");
	try{

		n = Integer.parseInt(dis.readLine());
		if(n<20)
		{
			throw new IOException();
		}

	}
	catch (IOException e) {
		System.out.println(e);
	}
		System.out.println("Hello Mr. "+n);
	}
}

class C {
	public void check() 
	{
	System.out.println("Check Starts");
	new D().test();
	System.out.println("Check Ends ");
	}
}


class B 
{
	public void put() {
	System.out.println("Put Starts");
		new C().check();
	System.out.println("Put Ends ");
	}
}


class DemoExp {
	public static void main(String[] args) //throws IOException
	 {
		System.out.println("Main Starts ");
		new B().put();
		System.out.println("Main Ends ");	
	}
}