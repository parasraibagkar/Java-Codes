package p1;

import java.io.*;

public class A {
	public void check()
	{
		System.out.println("this is check method of class A in package p1");
	}
}