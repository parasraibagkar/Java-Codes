class Jack {
	public static void main(String[] args) {
		SOP.disp("Hello from Jack class");
	}
}