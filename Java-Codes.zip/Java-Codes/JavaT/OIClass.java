class Oclass {
	class Iclass {
		 void set()
		{}

	}//Iclass ends 
	public void get()
	{
		//Iclass i = new Iclass();
		//i.set();
	}//get ends

	public void put()
	{
		class Nclass {
			public void search()
			{}
		}//Nclass ends
	}//put ends
	public void chair() {

		class Gclass {
			public void stop()
			{}
		}//Gclass ends
	}//chair ends

	Iclass g = new Iclass();
}//Oclass ends