class A extends Thread
{
	public void run() {}
}

class ThreadState
{
	public static void main(String[] args) {
		A a1 = new A();
		a1.start();
		a1.start();
	}
}