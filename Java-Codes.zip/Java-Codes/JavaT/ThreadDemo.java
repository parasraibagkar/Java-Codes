class A implements Runnable
{
	public void run() {
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Thread A: "+i);
		}
	}
}//class ends

class B extends Thread
{
	public void run() {
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Thread B: "+i);
		}
	}
}//class ends

class C extends Thread
{
	public void run() {
		int i;
		for (i=0;i<10 ;i++ ) {
			System.out.println("	Thread C: "+i);
		}
	}
}//class ends

class ThreadDemo {
	public static void main(String[] args) {
		System.out.println("Main starts");
		A a1 = new A();
		B b1 = new B();
		C c1 = new C();
		Thread t1 = new Thread(a1);
		t1.setPriority(5);
		b1.setPriority(1);
		c1.setPriority(10);
		t1.start();	
		b1.start();
		c1.start();
		System.out.println("Main ends");
	}
}