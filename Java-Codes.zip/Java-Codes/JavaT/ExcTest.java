import java.io.*;

class ExcTest
{
public static void main(String[] args)throws IOException {
	int a=0,b=0,c=0,n=0;

	int arr[] = {10,20,30,40,50};
	DataInputStream dis = new DataInputStream(System.in);
	System.out.println ("Enter First Number");
	a = Integer.parseInt(dis.readLine());
	try{
		System.out.println ("Enter Second Number");
		b = Integer.parseInt(dis.readLine());
		System.out.println ("Performing Division ");
		c = a/b;
		System.out.println ("Division is "+c);
		System.out.println ("Enter Index Number you want to check ");
		n = Integer.parseInt(dis.readLine());
		System.out.println ("Requested Element is "+arr[n]);
		System.out.println ("Try block ends");
	}
	catch (ArithmeticException e) {
		System.out.println ("can't divide by zero ");	
	}
	catch (ArrayIndexOutOfBoundsException e)
	//catch (Exception e) 
	 {
		//System.out.println ("Something went wrong");
		System.out.println ("\n Invalid index number \n");
	}
	/*catch (NumberFormatException e) {
		System.out.println ("Invalid Input Value");
	}*/
	finally{
		System.out.println ("Finally block executes ");
	}
	System.out.println ("Try-Catch-Finally ends");
	System.out.println ("Main ends");
}
}