package p2;

import java.io.*;

public class A {
	public void put()
	{
		System.out.println("this is check method of class A in package p2");
	}
}