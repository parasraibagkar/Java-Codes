import java.sql.*;

class Dbtype1
{
public static void main(String[] args) throws SQLException
{

        Connection conn=DriverManager.getConnection("jdbc:ucanaccess://C:\\projava\\database.accdb");
        Statement stment = conn.createStatement();
        stment.executeUpdate("insert into info values('Notepad','Notepad')");
        ResultSet rs = stment.executeQuery("select * from info");
        while(rs.next())
        {

            System.out.println(rs.getString("username")+"\t"+rs.getString("password"));
        }
    


}
}