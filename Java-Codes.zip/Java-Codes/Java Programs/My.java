class My {
	 int a;
		public static void main(String args[]) {
		int paras[]=new int[10];
		System.out.println("worked");

		//t2 = (Test)t1.clone();
	}
}