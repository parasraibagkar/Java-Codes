//program to study Vector
import java.util.*;

class A {
	public static Vector data = new Vector();
}
class F extends A {
	
}
class B extends A { 
 			F f = new F(); 
 			void check() {
 				System.out.println("Object of F in class B"+f.hashCode());
 				A.data.addElement(f);
 			}
 		}
class C extends A{ 
 			B b = new B();
 			void check() {
 				System.out.println("Object of B in class C"+b.hashCode());
 				A.data.addElement(b);
 			}
		}
class D extends A{
 			C c = new C();
 			void check() {
 				System.out.println("Object of C in class D"+c.hashCode());
 				A.data.addElement(c);
 			}
		}
class E {
public static void main(String[] args) {
 	
 	A a = new A();
 	F f = new F(); 
 	B b1 = new B();
 	C c1 = new C();
 	D d1 = new D();
 	int i,n;
 	b1.check();
 	c1.check();
 	d1.check();
 	System.out.println("Capacity is "+A.data.capacity());
 	System.out.println("Size is "+A.data.size());
 	for (i=0;i<A.data.size() ;i++ ) {
 		System.out.println((A)A.data.elementAt(i));
 	}
 	System.out.println((A)A.data.lastElement());
 } 
}