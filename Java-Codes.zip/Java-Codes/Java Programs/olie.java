class Sunday {
	public void sun()
	{
		System.out.println("Sunday");
	}
}

	class Monday {
		public void mon()
		{
			System.out.println("Monday");
		}
}

	class Tuesday {
		public void tue()
		{
			System.out.println("Tuesday");
		}
}