class Soul 
	{
		System.out.println("My Soul");
	}
	
