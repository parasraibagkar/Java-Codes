//program to study Inheritance
 class A {
	public void demo()
	{
		System.out.println("Demo of A ");
	}
	public void check()
	{
		System.out.println("Check of A");
	}
}

class B extends A {
	public void demo()
	{
		System.out.println("Demo of B ");
	}
	public void check()
	{
		System.out.println("Check of B");
	}
}

class C {
	public static void main(String[] args) {
		/* 
		*/
		A ref;
		B b1 = new B();
		ref=b1;

		System.out.println("Using b1");
		b1.check();
		b1.demo();
		System.out.println("Using ref");
		ref.check();
		ref.demo(); 
		
	}
}