	class Test {  


		 public String toString()
		{
			return ("This is Test Object");
		}
	}